import {Observable} from 'rxjs';
import {Session} from './Session';
import {Formation} from './formation';
export class FormationMetiers extends Formation {
duree :String ;
}
