import{Utilisateur } from './utilisateur' ;
export class Admin extends Utilisateur {


}
