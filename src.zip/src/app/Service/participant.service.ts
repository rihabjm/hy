import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Participant} from '../Model/participant';
@Injectable({
  providedIn: 'root'
})
export class ParticipantService {

 constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '//add';
private urld = this.url + '/products';



public  createProduct(product: object, idCategory: number): Observable<object> {
    return this.httpClient.post(`${this.urld}/${idCategory}`, product);
  }

 public save(participant:Participant): Observable<any> {

  return this.httpClient.post(this.url+'/add',participant );
  }

  public  getAll(): Observable<Participant[]> {
    return this.httpClient.get<Participant[]>(this.url+'/get');
  }
 public update(participant:Participant): Observable<any> {

  return this.httpClient.put(this.url+'/update' ,participant);
  }


   public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }
}
