import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalendrierformateurComponent } from './calendrierformateur.component';

describe('CalendrierformateurComponent', () => {
  let component: CalendrierformateurComponent;
  let fixture: ComponentFixture<CalendrierformateurComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalendrierformateurComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalendrierformateurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
