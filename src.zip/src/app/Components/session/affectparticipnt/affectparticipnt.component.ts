import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {Session} from '../../../Model/Session';
import {SessionService} from '../../../Service/session.service';

@Component({
  selector: 'app-affectparticipnt',
  templateUrl: './affectparticipnt.component.html',
  styleUrls: ['./affectparticipnt.component.scss']
})
export class AffectparticipntComponent implements OnInit {
    sub;
    id ;
    session :Session =new Session();
  constructor(private _Activatedroute:ActivatedRoute, private router: Router, private sessionservice :SessionService)
  {}


  ngOnInit() {


      this.sub=this._Activatedroute.paramMap.subscribe(params => {
         console.log(params);
                   this.id = params.get('id');
              this.sessionservice.get(this.id)
      .subscribe(data => {
        console.log(data)
        this.session = data;
      }, error => console.log(error));

      });

  }

}
