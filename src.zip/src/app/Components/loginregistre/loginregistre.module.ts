import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginregistreRoutingModule } from './loginregistre-routing.module';
import { LoginComponent } from './login/login.component';
import { RegistreComponent } from './registre/registre.component';
import { LoginregistreComponent } from './loginregistre/loginregistre.component';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';
import { ModifprofilComponent } from './modifprofil/modifprofil.component';
import { ModifmdpComponent } from './modifmdp/modifmdp.component';


@NgModule({
  declarations: [LoginComponent, RegistreComponent, LoginregistreComponent, ModifprofilComponent, ModifmdpComponent],
  imports: [
    CommonModule,
    LoginregistreRoutingModule ,  FormsModule, ReactiveFormsModule
  ]
})
export class LoginregistreModule { }
