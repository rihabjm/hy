import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginregistreComponent } from './loginregistre.component';

describe('LoginregistreComponent', () => {
  let component: LoginregistreComponent;
  let fixture: ComponentFixture<LoginregistreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginregistreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginregistreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
