import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AjoutsalleComponent } from './ajoutsalle.component';

describe('AjoutsalleComponent', () => {
  let component: AjoutsalleComponent;
  let fixture: ComponentFixture<AjoutsalleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AjoutsalleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AjoutsalleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
