import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalleRoutingModule } from './salle-routing.module';
import { AjoutsalleComponent } from './ajoutsalle/ajoutsalle.component';
import { SupprimesalleComponent } from './supprimesalle/supprimesalle.component';
import { ListsalleComponent } from './listsalle/listsalle.component';
import { ModifiersalleComponent } from './modifiersalle/modifiersalle.component';
import { SalleComponent } from './salle/salle.component';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';


@NgModule({
  declarations: [AjoutsalleComponent, SupprimesalleComponent, ListsalleComponent, ModifiersalleComponent, SalleComponent],
  imports: [
    CommonModule,
    SalleRoutingModule , FormsModule, ReactiveFormsModule
  ]
})
export class SalleModule { }
