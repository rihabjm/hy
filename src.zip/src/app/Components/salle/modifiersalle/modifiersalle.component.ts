import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modifiersalle',
  templateUrl: './modifiersalle.component.html',
  styleUrls: ['./modifiersalle.component.scss']
})
export class ModifiersalleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
