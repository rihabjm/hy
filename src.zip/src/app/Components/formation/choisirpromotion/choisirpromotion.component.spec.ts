import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChoisirpromotionComponent } from './choisirpromotion.component';

describe('ChoisirpromotionComponent', () => {
  let component: ChoisirpromotionComponent;
  let fixture: ComponentFixture<ChoisirpromotionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChoisirpromotionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChoisirpromotionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
