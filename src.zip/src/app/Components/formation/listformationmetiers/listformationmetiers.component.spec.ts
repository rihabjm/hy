import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListformationmetiersComponent } from './listformationmetiers.component';

describe('ListformationmetiersComponent', () => {
  let component: ListformationmetiersComponent;
  let fixture: ComponentFixture<ListformationmetiersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListformationmetiersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListformationmetiersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
