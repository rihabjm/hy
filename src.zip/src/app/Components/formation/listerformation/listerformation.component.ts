import { Component, OnInit } from '@angular/core';
import {FormationService} from '../../../Service/formation.service';
import {Formation} from '../../../Model/formation';
import {FormationMetiers} from '../../../Model/formation-metiers';
import {FormationMetiersService} from '../../../Service/formation-metiers.service';
import {Formationmodule} from '../../../Model/formationmodule';
import {FormationmoduleService} from '../../../Service/formationmodule.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-listerformation',
  templateUrl: './listerformation.component.html',
  styleUrls: ['./listerformation.component.scss']
})
export class ListerformationComponent implements OnInit {

  constructor(private router: Router ,private  formationservice : FormationService , private formationsmetiersservice :FormationMetiersService ,private formationmoduleserice: FormationmoduleService) { }
 ngOnInit() {
this.getAll() ;
  }



formations : Formation[] = new Array();

obj : String ;




private getAll() {
 this.formationservice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}

private getAllformationsmetiers() {
 this.formationsmetiersservice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}



    private getAllmodule() {
 this.formationmoduleserice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}






delete(id: number) {

    this.formationservice.delete(id).subscribe(data => {
      if (data.success) {


      this.getAll();


} else {
  }

    }, ex => {

     console.log(ex);
    });
  }



getAllformationsBYintitule(obj : String) {
 this.formationservice.getformationBYintitule(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsBydatedebut( obj: String) {
 this.formationservice.getformationBydatedebut(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsBydatefin(datefin : String) {
 this.formationservice.getformationBydatefin(datefin).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsyetat(obj : String) {
 this.formationservice.getformationByetat(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsBytype(obj : String) {
 this.formationservice.getformationBytype(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}

private getAllformationsByprix(obj : String) {
 this.formationservice.getformationByprix(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}

}
